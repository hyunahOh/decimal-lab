import type { DecimalData } from "./decimal";
import type { RoundingMode } from "./arithmetic";
import { add, divide, multiply, setScale } from "./arithmetic";
import { MAX_OUTPUT_LENGTH, toPlainString } from "./format";
import { checkScale, createDecimal } from "./internal";
import { parseScientific } from "./parse";
import { powerProduct, remainder, squareRoot } from "./advanced";

export type BigSource = string | number | bigint | BigValue;
export type BigRoundingMode = 0 | 1 | 2 | 3;
export type Big = BigValue;

export interface BigConstructor {
  (value: BigSource): BigValue;
  (): BigConstructor;
  new(value: BigSource): BigValue;
  readonly prototype: BigValue;
  DP: number;
  RM: number;
  NE: number;
  PE: number;
  strict: boolean;
  readonly roundDown: 0;
  readonly roundHalfUp: 1;
  readonly roundHalfEven: 2;
  readonly roundUp: 3;
}

function decimalPlaces(value: number, negative = false): number {
  if (!Number.isInteger(value) || value < (negative ? -1_000_000 : 0) || value > 1_000_000) {
    throw new RangeError("Invalid decimal places");
  }
  return value;
}

function rounding(value: number): RoundingMode {
  const modes: RoundingMode[] = ["DOWN", "HALF_UP", "HALF_EVEN", "UP"];
  if (!Number.isInteger(value) || value < 0 || value > 3) throw new RangeError("Invalid rounding mode");
  return modes[value]!;
}

function normalize(value: DecimalData): DecimalData {
  if (value.coefficient === 0 || value.coefficient === 0n) return createDecimal(0, 0);
  const text = value.coefficient.toString();
  const trimmed = text.replace(/0+$/, "");
  return createDecimal(BigInt(trimmed), checkScale(value.scale - (text.length - trimmed.length)));
}

function precision(sd: number): number {
  if (!Number.isInteger(sd) || sd < 1 || sd > 1_000_000) throw new RangeError("Invalid precision");
  return sd;
}

/** Calculate output size before padding or expanding a decimal exponent. */
function formatDigits(digits: string, exponent: bigint, scientific: boolean, negative: boolean, width = digits.length): string {
  const size = BigInt(Math.max(width, digits.length));
  const exponentText = `${exponent >= 0n ? "+" : ""}${exponent}`;
  const length = (negative ? 1n : 0n) + (scientific
    ? size + (size > 1n ? 1n : 0n) + 1n + BigInt(exponentText.length)
    : exponent < 0n ? 1n - exponent + size
    : exponent + 1n >= size ? exponent + 1n : size + 1n);
  if (length > BigInt(MAX_OUTPUT_LENGTH)) throw new RangeError("Output exceeds length limit");
  digits = digits.padEnd(width, "0");
  let text: string;
  if (scientific) text = `${digits[0]}${digits.length > 1 ? `.${digits.slice(1)}` : ""}e${exponentText}`;
  else if (exponent < 0n) text = `0.${"0".repeat(Number(-exponent - 1n))}${digits}`;
  else {
    const point = Number(exponent + 1n);
    text = point >= digits.length ? digits + "0".repeat(point - digits.length)
      : `${digits.slice(0, point)}.${digits.slice(point)}`;
  }
  return (negative ? "-" : "") + text;
}

/** Immutable big.js-style facade over the coefficient/scale arithmetic. */
export class BigValue {
  private readonly data: DecimalData;
  private readonly negative: boolean;
  private readonly context: BigConstructor;

  constructor(value: DecimalData, negative: boolean, context: BigConstructor) {
    this.data = normalize(value);
    this.negative = negative;
    this.context = context;
    Object.defineProperty(this, "constructor", { value: context });
  }

  private get zero(): boolean { return this.data.coefficient === 0 || this.data.coefficient === 0n; }
  private get digits(): string { return this.data.coefficient.toString().replace(/^-/, ""); }
  private get exponent(): bigint { return this.zero ? 0n : BigInt(this.digits.length - 1) - BigInt(this.data.scale); }
  private result(value: DecimalData, negative = value.coefficient < 0): BigValue {
    return new BigValue(value, negative, this.context);
  }

  plus(value: BigSource): BigValue {
    const other = this.context(value);
    const result = add(this.data, other.data);
    return this.result(result, result.coefficient < 0 || (this.zero && other.zero && this.negative && other.negative));
  }

  minus(value: BigSource): BigValue { return this.plus(this.context(value).neg()); }
  add(value: BigSource): BigValue { return this.plus(value); }
  sub(value: BigSource): BigValue { return this.minus(value); }
  mul(value: BigSource): BigValue { return this.times(value); }

  times(value: BigSource): BigValue {
    const other = this.context(value);
    return this.result(multiply(this.data, other.data), this.negative !== other.negative);
  }

  div(value: BigSource): BigValue {
    const other = this.context(value);
    const dp = decimalPlaces(this.context.DP);
    const mode = rounding(this.context.RM);
    return this.result(divide(this.data, other.data, dp, mode), this.negative !== other.negative);
  }

  mod(value: BigSource): BigValue {
    const other = this.context(value);
    if (other.zero) throw new RangeError("Division by zero");
    if (this.abs().lt(other.abs())) return this.result(this.data, this.negative);
    // Exact multiples produce positive zero, as subtraction does in big.js.
    const data = remainder(this.data, other.data);
    return this.result(data);
  }

  pow(exponent: number): BigValue {
    if (!Number.isInteger(exponent) || Math.abs(exponent) > 1_000_000) throw new RangeError("Invalid exponent");
    let count = Math.abs(exponent);
    let result = this.context("1");
    let base: BigValue = this;
    while (count > 0) {
      if (count % 2 === 1) result = this.result(powerProduct(result.data, base.data), result.negative !== base.negative);
      count = Math.floor(count / 2);
      if (count > 0) base = this.result(powerProduct(base.data, base.data), false);
    }
    return exponent < 0 ? this.context("1").div(result) : result;
  }

  sqrt(): BigValue {
    if (this.zero) return this.result(this.data, this.negative);
    if (this.negative) throw new RangeError("No square root");
    const dp = decimalPlaces(this.context.DP);
    rounding(this.context.RM);
    return this.result(squareRoot(this.data, dp, this.context.RM));
  }

  prec(sd: number, rm = this.context.RM): BigValue {
    precision(sd);
    return this.roundSignificant(sd, rm);
  }

  private roundSignificant(sd: number, rm: number): BigValue {
    const mode = rounding(rm);
    if (this.zero || sd >= this.digits.length) return this.result(this.data, this.negative);
    const scale = checkScale(this.data.scale - (this.digits.length - sd));
    return this.result(setScale(this.data, scale, mode), this.negative);
  }

  round(dp = 0, rm = this.context.RM): BigValue {
    decimalPlaces(dp, true);
    const mode = rounding(rm);
    // round specifies a maximum number of places; it does not append zeros.
    return this.result(dp >= this.data.scale ? this.data : setScale(this.data, dp, mode), this.negative);
  }

  abs(): BigValue { return this.negative ? this.neg() : this.result(this.data, false); }
  neg(): BigValue { return this.result(createDecimal(-this.data.coefficient, this.data.scale), !this.negative); }

  cmp(value: BigSource): -1 | 0 | 1 {
    const other = this.context(value);
    if (this.zero && other.zero) return 0;
    if (this.negative !== other.negative) return this.negative ? -1 : 1;
    let magnitude: -1 | 0 | 1;
    if (this.zero || other.zero) magnitude = this.zero ? -1 : 1;
    else {
      const a = this.data.coefficient.toString().replace(/^-/, "");
      const b = other.data.coefficient.toString().replace(/^-/, "");
      const ae = BigInt(a.length) - BigInt(this.data.scale);
      const be = BigInt(b.length) - BigInt(other.data.scale);
      if (ae !== be) magnitude = ae < be ? -1 : 1;
      else {
        const width = Math.max(a.length, b.length);
        const left = a.padEnd(width, "0"), right = b.padEnd(width, "0");
        magnitude = left === right ? 0 : left < right ? -1 : 1;
      }
    }
    return magnitude === 0 ? 0 : this.negative ? (magnitude === 1 ? -1 : 1) : magnitude;
  }

  eq(value: BigSource): boolean { return this.cmp(value) === 0; }
  gt(value: BigSource): boolean { return this.cmp(value) > 0; }
  gte(value: BigSource): boolean { return this.cmp(value) >= 0; }
  lt(value: BigSource): boolean { return this.cmp(value) < 0; }
  lte(value: BigSource): boolean { return this.cmp(value) <= 0; }

  toString(): string {
    const exponent = this.exponent;
    return formatDigits(this.digits, exponent, exponent <= BigInt(this.context.NE) || exponent >= BigInt(this.context.PE), this.negative && !this.zero);
  }

  toExponential(dp?: number, rm = this.context.RM): string {
    if (dp !== undefined) decimalPlaces(dp);
    const rounded = dp === undefined ? this : this.roundSignificant(dp + 1, rm);
    return formatDigits(rounded.digits, rounded.exponent, true, this.negative && !this.zero,
      dp === undefined ? rounded.digits.length : dp + 1);
  }

  toPrecision(sd?: number, rm = this.context.RM): string {
    if (sd === undefined) return this.toString();
    precision(sd);
    const rounded = this.roundSignificant(sd, rm);
    const exponent = rounded.exponent;
    const scientific = exponent >= BigInt(sd) || exponent <= BigInt(this.context.NE) || exponent >= BigInt(this.context.PE);
    return formatDigits(rounded.digits, exponent, scientific, this.negative && !this.zero, sd);
  }

  toFixed(dp?: number, rm = this.context.RM): string {
    if (dp === undefined) return toPlainString(this.data);
    decimalPlaces(dp);
    const rounded = setScale(this.data, dp, rounding(rm));
    const text = toPlainString(rounded);
    // A negative nonzero value rounded to zero retains its sign in toFixed.
    const result = this.negative && !this.zero && rounded.coefficient === 0 ? `-${text}` : text;
    if (result.length > MAX_OUTPUT_LENGTH) throw new RangeError("Plain output exceeds length limit");
    return result;
  }

  toJSON(): string { return this.toString(); }

  valueOf(): string {
    if (this.context.strict === true) throw new TypeError("valueOf disallowed in strict mode");
    return this.zero && this.negative ? `-${this.toString()}` : this.toString();
  }

  toNumber(): number {
    const value = this.zero && this.negative ? -0 : Number(this.toString());
    if (this.context.strict === true && (!Number.isFinite(value) || !this.eq(String(value)))) {
      throw new Error("Imprecise conversion");
    }
    return value;
  }

  /** Used by constructors to copy values without parsing or losing negative zero. */
  static copy(value: BigValue, context: BigConstructor): BigValue {
    return new BigValue(value.data, value.negative, context);
  }
}

export interface BigValue {
  readonly constructor: BigConstructor;
}

function createBigConstructor(): BigConstructor {
  const factory = function(this: unknown, value?: BigSource): BigValue | BigConstructor {
    if (!new.target && arguments.length === 0) return createBigConstructor();
    if (value instanceof BigValue) return BigValue.copy(value, Big);
    if (Big.strict === true && typeof value !== "string" && typeof value !== "bigint") {
      throw new TypeError("Invalid value");
    }
    const text = typeof value === "number" && Object.is(value, -0) ? "-0" : String(value);
    // big.js does not accept a leading plus sign.
    if (!/^-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e[+-]?[0-9]+)?(?![\s\S])/i.test(text)) {
      throw new Error("Invalid number");
    }
    return new BigValue(parseScientific(text), text[0] === "-", Big);
  };
  const Big = factory as BigConstructor;
  Object.assign(Big, { DP: 20, RM: 1, NE: -7, PE: 21, strict: false,
    roundDown: 0, roundHalfUp: 1, roundHalfEven: 2, roundUp: 3 });
  Object.defineProperty(Big, "prototype", { value: BigValue.prototype });
  return Big;
}

export const Big = createBigConstructor();
export { Big as default };
